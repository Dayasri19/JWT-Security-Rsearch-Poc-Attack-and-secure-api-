# task2_api.py — README

Simple Flask API for Task 2 (POST & GET).

## Requirements
- Python 3.8+
- Flask

## Setup
```bash
pip install -r requirements.txt
python task2_api.py
```

## Endpoints
- `POST /items` — Add item `{ "name": "..." }`
- `GET /items` — List items
- `GET /` — Health check
