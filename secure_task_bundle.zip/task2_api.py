#!/usr/bin/env python3
"""
task2_api.py — Simple Flask API with POST and GET
Author: Dayasri
"""

from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

# --- In-memory store (replace with DB in production) ---
items = []  # list of dicts {id, name, createdAt}


# --- POST /items ---
@app.route('/items', methods=['POST'])
def create_item():
    """Create a new item"""
    data = request.get_json()
    if not data or "name" not in data or not isinstance(data["name"], str):
        return jsonify({"error": "Field 'name' is required (string)"}), 400

    item = {
        "id": len(items) + 1,
        "name": data["name"].strip(),
        "createdAt": datetime.utcnow().isoformat() + "Z",
    }
    items.append(item)
    return jsonify({"message": "Item created", "item": item}), 201


# --- GET /items ---
@app.route('/items', methods=['GET'])
def list_items():
    """List all items"""
    return jsonify({"count": len(items), "items": items})


# --- Health check ---
@app.route('/', methods=['GET'])
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat() + "Z"})


# --- Start server ---
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
