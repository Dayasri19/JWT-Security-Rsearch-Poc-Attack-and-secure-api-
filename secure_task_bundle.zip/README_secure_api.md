# secure_api.js — README

Minimal secure Express API with JWT authentication.

## Requirements
- Node.js 16+
- npm

## Setup
1. Install dependencies:
   ```bash
   npm install express helmet express-rate-limit bcrypt jsonwebtoken express-validator dotenv
   ```

2. Create a `.env` in the same folder (example):
   ```
   PORT=3000
   JWT_ALGORITHM=HS256
   JWT_SECRET=please_change_this_secret_in_prod
   BCRYPT_SALT_ROUNDS=10
   JWT_EXPIRES_IN=1h
   ```

3. Run:
   ```bash
   node secure_api.js
   ```

## Endpoints
- `POST /register` — body `{ username, password }`
- `POST /login` — body `{ username, password }`
- `GET /profile` — protected, requires `Authorization: Bearer <token>`
- `GET /` — health check
