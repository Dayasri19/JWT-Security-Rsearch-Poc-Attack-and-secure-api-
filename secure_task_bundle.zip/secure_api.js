require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const fs = require('fs');

const app = express();
app.use(helmet());
app.use(express.json());

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 60, // 60 requests per IP per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(apiLimiter);

// --- Configuration (from environment) ---
const PORT = process.env.PORT || 3000;
const JWT_ALGORITHM = process.env.JWT_ALGORITHM || 'HS256'; // 'HS256' or 'RS256'
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h'; // e.g., '1h', '15m'
const BCRYPT_SALT_ROUNDS = parseInt(process.env.BCRYPT_SALT_ROUNDS || '10', 10);

// HS256 secret
const JWT_SECRET = process.env.JWT_SECRET || 'please_change_this_secret_in_prod';

// RS256 keys (optional) - support loading from file paths if provided
const PRIVATE_KEY = process.env.PRIVATE_KEY || (process.env.PRIVATE_KEY_PATH ? fs.readFileSync(process.env.PRIVATE_KEY_PATH, 'utf8') : null);
const PUBLIC_KEY = process.env.PUBLIC_KEY || (process.env.PUBLIC_KEY_PATH ? fs.readFileSync(process.env.PUBLIC_KEY_PATH, 'utf8') : null);

// Basic runtime checks
if (JWT_ALGORITHM === 'HS256' && !JWT_SECRET) {
  console.error('HS256 selected but JWT_SECRET is missing. Set JWT_SECRET in .env');
  process.exit(1);
}
if (JWT_ALGORITHM === 'RS256' && (!PRIVATE_KEY || !PUBLIC_KEY)) {
  console.error('RS256 selected but PRIVATE_KEY/PUBLIC_KEY missing. Set them in .env or provide file paths.');
  process.exit(1);
}

// --- In-memory user store (replace with DB in production) ---
const users = new Map(); // username -> { id, username, passwordHash, createdAt }

// --- Helpers ---
function createJwt(payload) {
  if (JWT_ALGORITHM === 'HS256') {
    return jwt.sign(payload, JWT_SECRET, { algorithm: 'HS256', expiresIn: JWT_EXPIRES_IN });
  } else if (JWT_ALGORITHM === 'RS256') {
    return jwt.sign(payload, PRIVATE_KEY, { algorithm: 'RS256', expiresIn: JWT_EXPIRES_IN });
  } else {
    throw new Error('Unsupported JWT_ALGORITHM');
  }
}

function verifyJwt(token) {
  if (JWT_ALGORITHM === 'HS256') {
    return jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });
  } else if (JWT_ALGORITHM === 'RS256') {
    return jwt.verify(token, PUBLIC_KEY, { algorithms: ['RS256'] });
  } else {
    throw new Error('Unsupported JWT_ALGORITHM');
  }
}

// Middleware: require Authorization: Bearer <token>
function authenticateMiddleware(req, res, next) {
  const auth = req.header('authorization');
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or malformed Authorization header' });
  }
  const token = auth.slice(7);
  try {
    const payload = verifyJwt(token);
    // attach user info to request (we store only username and id in token below)
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token', details: err.message });
  }
}

// --- Routes ---

/**
 * POST /register
 * Body: { username, password }
 */
app.post('/register',
  // validation rules
  body('username')
    .isString().trim().isLength({ min: 3, max: 50 }).withMessage('username 3-50 chars'),
  body('password')
    .isString().isLength({ min: 8, max: 200 }).withMessage('password must be 8+ chars'),
  async (req, res) => {
    // input validation
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, password } = req.body;
    const normalized = username.toLowerCase();

    if (users.has(normalized)) {
      return res.status(409).json({ error: 'User already exists' });
    }

    try {
      const saltRounds = BCRYPT_SALT_ROUNDS;
      const passwordHash = await bcrypt.hash(password, saltRounds);
      const id = Math.random().toString(36).slice(2, 10); // simple id - replace with DB-generated id
      const user = { id, username: normalized, passwordHash, createdAt: new Date().toISOString() };
      users.set(normalized, user);
      // Do NOT return passwordHash
      res.status(201).json({ message: 'User registered', user: { id: user.id, username: user.username } });
    } catch (err) {
      console.error('Error hashing password', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

/**
 * POST /login
 * Body: { username, password }
 * Returns: { token, expiresIn }
 */
app.post('/login',
  body('username').isString().trim().notEmpty(),
  body('password').isString().notEmpty(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { username, password } = req.body;
    const normalized = username.toLowerCase();
    const user = users.get(normalized);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    try {
      const match = await bcrypt.compare(password, user.passwordHash);
      if (!match) return res.status(401).json({ error: 'Invalid credentials' });

      // Create token payload (minimal)
      const payload = { sub: user.id, username: user.username };
      const token = createJwt(payload);
      res.json({ token, token_type: 'Bearer', expires_in: JWT_EXPIRES_IN });
    } catch (err) {
      console.error('Login error', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

/**
 * GET /profile
 * Protected route — returns basic profile info
 */
app.get('/profile', authenticateMiddleware, (req, res) => {
  // req.user was set by authenticateMiddleware
  const { sub: id, username } = req.user;
  // In a real app, fetch user from DB by id
  const user = users.get(username) || [...users.values()].find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  res.json({
    id: user.id,
    username: user.username,
    createdAt: user.createdAt,
    // do not include passwordHash
  });
});

// Health check
app.get('/', (_req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// Start server
app.listen(PORT, () => {
  console.log(`Secure API running on port ${PORT} (JWT alg: ${JWT_ALGORITHM})`);
});
