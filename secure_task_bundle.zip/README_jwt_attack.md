# jwt_attack_demo.py — README

Demonstration of weak JWT usage and simple attacks (for research/education).

## Requirements
- Python
- PyJWT

## Run
```bash
pip install -r requirements.txt
python jwt_attack_demo.py
```

## Notes
- This script generates a token with a weak secret and demonstrates brute-force and alg=none attacks.
- Use only in a safe, legal, and controlled environment.
